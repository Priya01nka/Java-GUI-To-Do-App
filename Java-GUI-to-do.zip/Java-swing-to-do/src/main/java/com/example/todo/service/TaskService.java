package com.example.todo.service;

import com.example.todo.model.Task;
import com.example.todo.repository.TaskRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    private final TaskRepository repo;

    public TaskService(TaskRepository repo) {
        this.repo = repo;
    }

    public List<Task> getAll() { return repo.findAll(); }
    public Task add(Task t) { return repo.save(t); }
    public void delete(Long id) { repo.deleteById(id); }
    public Optional<Task> findById(Long id) { return repo.findById(id); }
    public Task update(Task t) { return repo.save(t); }
}
